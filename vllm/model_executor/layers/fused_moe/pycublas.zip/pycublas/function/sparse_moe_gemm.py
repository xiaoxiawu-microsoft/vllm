import torch
import pycublas
import pycublas.constant

class SparseMoE_F16_F8_F16(torch.autograd.Function):
    @staticmethod
    def forward(ctx, A, B, C=None):
        pass